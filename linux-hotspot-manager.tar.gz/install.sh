#!/usr/bin/env bash
# ==============================================================================
# Linux Hotspot Manager (MyPublicWiFi Clone) - Installer Script
# Optimized for Parrot OS 7.3, Debian 12/13, and KDE Plasma
# ==============================================================================
set -euo pipefail

APP_NAME="Linux Hotspot Manager"
BIN_NAME="linux-hotspot-manager"
SERVICE_NAME="linux-hotspot-manager"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}[ERROR] This script must be run as root (or with sudo).${NC}"
        echo -e "Usage: sudo $0 [OPTIONS]"
        exit 1
    fi
}

do_uninstall() {
    echo -e "${YELLOW}${BOLD}Uninstalling ${APP_NAME}...${NC}"

    # Stop and disable services
    systemctl stop linux-hotspot-manager.service 2>/dev/null || true
    systemctl stop linux-hotspot-manager-portal.service 2>/dev/null || true
    systemctl disable linux-hotspot-manager.service 2>/dev/null || true
    systemctl disable linux-hotspot-manager-portal.service 2>/dev/null || true

    # Remove files
    echo "Removing application files..."
    rm -f /usr/bin/linux-hotspot-manager
    rm -rf /usr/lib/linux-hotspot-manager
    rm -rf /usr/share/linux-hotspot-manager
    rm -f /usr/share/applications/com.shazid.LinuxHotspotManager.desktop
    rm -f /usr/share/icons/hicolor/scalable/apps/com.shazid.LinuxHotspotManager.svg
    rm -f /usr/share/metainfo/com.shazid.LinuxHotspotManager.metainfo.xml
    rm -f /usr/share/dbus-1/system-services/com.shazid.LinuxHotspotManager.service
    rm -f /etc/dbus-1/system.d/com.shazid.LinuxHotspotManager.conf
    rm -f /etc/polkit-1/actions/com.shazid.LinuxHotspotManager.policy
    rm -rf /etc/linux-hotspot-manager
    rm -f /lib/systemd/system/linux-hotspot-manager.service
    rm -f /lib/systemd/system/linux-hotspot-manager-portal.service
    rm -f /lib/systemd/system/linux-hotspot-manager-dnsmasq.service

    # Reload system daemons
    systemctl daemon-reload || true
    systemctl reload dbus.service 2>/dev/null || true
    update-desktop-database 2>/dev/null || true
    gtk-update-icon-cache -q /usr/share/icons/hicolor 2>/dev/null || true

    echo -e "${GREEN}${BOLD}✓ ${APP_NAME} has been successfully uninstalled.${NC}"
    exit 0
}

do_install() {
    echo -e "${CYAN}${BOLD}======================================================${NC}"
    echo -e "${CYAN}${BOLD}     Installing ${APP_NAME} v4.1.0             ${NC}"
    echo -e "${CYAN}${BOLD}     MyPublicWiFi Clone for Parrot OS / Linux        ${NC}"
    echo -e "${CYAN}${BOLD}======================================================${NC}"

    # 1. Install dependencies if apt is available
    if command -v apt-get >/dev/null 2>&1; then
        echo -e "\n${BLUE}[1/6] Checking system dependencies...${NC}"
        export DEBIAN_FRONTEND=noninteractive
        DEPS=(
            python3
            python3-gi
            gir1.2-gtk-4.0
            gir1.2-adw-1
            python3-dbus-next
            network-manager
            nftables
            dnsmasq
            iproute2
            dbus
            polkitd
        )
        MISSING_DEPS=()
        for dep in "${DEPS[@]}"; do
            if ! dpkg -s "$dep" >/dev/null 2>&1; then
                MISSING_DEPS+=("$dep")
            fi
        done

        if [[ ${#MISSING_DEPS[@]} -gt 0 ]]; then
            echo "Installing missing packages: ${MISSING_DEPS[*]}..."
            apt-get update -qq
            apt-get install -y -qq "${MISSING_DEPS[@]}"
        else
            echo "✓ All system dependencies are already installed."
        fi
    fi

    # 2. Create directories
    echo -e "\n${BLUE}[2/6] Creating directories...${NC}"
    mkdir -p /usr/lib/linux-hotspot-manager \
             /usr/share/linux-hotspot-manager/lang \
             /usr/share/applications \
             /usr/share/icons/hicolor/scalable/apps \
             /usr/share/metainfo \
             /usr/share/dbus-1/system-services \
             /etc/dbus-1/system.d \
             /etc/polkit-1/actions \
             /etc/linux-hotspot-manager \
             /lib/systemd/system \
             /var/lib/linux-hotspot-manager

    chmod 750 /var/lib/linux-hotspot-manager

    # 3. Create service user if missing
    if ! id -u linux-hotspot-manager >/dev/null 2>&1; then
        useradd -r -s /usr/sbin/nologin -d /var/lib/linux-hotspot-manager linux-hotspot-manager || true
    fi

    # 4. Copy application files
    echo -e "${BLUE}[3/6] Copying application files...${NC}"
    cp "$SRC_DIR/src/main.py" /usr/lib/linux-hotspot-manager/main.py
    cp "$SRC_DIR/src/i18n.py" /usr/lib/linux-hotspot-manager/i18n.py
    cp "$SRC_DIR/host/linux-hotspot-manager-service.py" /usr/lib/linux-hotspot-manager/linux-hotspot-manager-service.py
    cp "$SRC_DIR/portal/server.py" /usr/lib/linux-hotspot-manager/portal-server.py
    cp -r "$SRC_DIR/data/lang/"* /usr/share/linux-hotspot-manager/lang/

    # Configs
    cp "$SRC_DIR/host/dnsmasq.conf" /etc/linux-hotspot-manager/dnsmasq.conf
    cp "$SRC_DIR/host/com.shazid.LinuxHotspotManager.service" /usr/share/dbus-1/system-services/
    cp "$SRC_DIR/dbus/com.shazid.LinuxHotspotManager.conf" /etc/dbus-1/system.d/
    cp "$SRC_DIR/polkit/com.shazid.LinuxHotspotManager.policy" /etc/polkit-1/actions/

    # Systemd units
    cp "$SRC_DIR/systemd/linux-hotspot-manager.service" /lib/systemd/system/
    cp "$SRC_DIR/systemd/linux-hotspot-manager-portal.service" /lib/systemd/system/
    cp "$SRC_DIR/systemd/linux-hotspot-manager-dnsmasq.service" /lib/systemd/system/

    # Desktop & Icon
    cp "$SRC_DIR/data/icon.svg" /usr/share/icons/hicolor/scalable/apps/com.shazid.LinuxHotspotManager.svg
    cp "$SRC_DIR/data/com.shazid.LinuxHotspotManager.metainfo.xml" /usr/share/metainfo/
    cp "$SRC_DIR/data/com.shazid.LinuxHotspotManager.desktop" /usr/share/applications/

    # Launcher
    cat > /usr/bin/linux-hotspot-manager <<'EOF'
#!/bin/sh
exec /usr/bin/python3 /usr/lib/linux-hotspot-manager/main.py "$@"
EOF
    chmod 755 /usr/bin/linux-hotspot-manager

    # 5. Reload daemons & start service
    echo -e "${BLUE}[4/6] Configuring and starting background services...${NC}"
    systemctl daemon-reload
    systemctl reload dbus.service 2>/dev/null || true
    systemctl enable linux-hotspot-manager.service
    systemctl restart linux-hotspot-manager.service

    # 6. Update desktop & icon caches
    echo -e "${BLUE}[5/6] Updating desktop environment caches...${NC}"
    update-desktop-database 2>/dev/null || true
    gtk-update-icon-cache -q /usr/share/icons/hicolor 2>/dev/null || true

    echo -e "\n${GREEN}${BOLD}======================================================${NC}"
    echo -e "${GREEN}${BOLD}✓ Installation Complete!                              ${NC}"
    echo -e "${GREEN}${BOLD}======================================================${NC}"
    echo -e "You can launch ${APP_NAME} by:"
    echo -e "  1. Running ${CYAN}${BOLD}linux-hotspot-manager${NC} in the terminal"
    echo -e "  2. Finding ${CYAN}${BOLD}Linux Hotspot Manager${NC} in the Application Launcher / KDE menu"
    echo -e "\nTo uninstall anytime, run: ${YELLOW}sudo $0 --uninstall${NC}\n"
}

# Main entrypoint
check_root

if [[ "${1:-}" == "--uninstall" || "${1:-}" == "-u" ]]; then
    do_uninstall
else
    do_install
fi
