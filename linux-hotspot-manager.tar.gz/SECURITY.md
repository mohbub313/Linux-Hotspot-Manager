# Security Policy

Please do not publish an undisclosed privilege-escalation or remote-code-execution issue in a public issue.

Report security issues privately to the repository maintainer. Include:
- affected version
- distribution and kernel
- reproduction steps
- expected vs actual behavior
- relevant logs with passwords, tokens and personal data removed

The host service is privileged and therefore receives extra review. User input must never become an unvalidated shell command.
