#!/usr/bin/env bash
set -euo pipefail
install -Dm755 host/linux-hotspot-manager-service.py /usr/lib/linux-hotspot-manager/linux-hotspot-manager-service.py
install -Dm755 portal/server.py /usr/lib/linux-hotspot-manager/portal-server.py
install -Dm644 host/com.shazid.LinuxHotspotManager.service /usr/share/dbus-1/system-services/com.shazid.LinuxHotspotManager.service
install -Dm644 polkit/com.shazid.LinuxHotspotManager.policy /usr/share/polkit-1/actions/com.shazid.LinuxHotspotManager.policy
install -Dm644 systemd/linux-hotspot-manager.service /usr/lib/systemd/system/linux-hotspot-manager.service
install -Dm644 systemd/linux-hotspot-manager-portal.service /usr/lib/systemd/system/linux-hotspot-manager-portal.service
install -d /var/lib/linux-hotspot-manager
systemctl daemon-reload
systemctl enable --now linux-hotspot-manager.service
echo "Host service installed."
