# Contributing

1. Fork the repository.
2. Create a focused branch.
3. Keep privileged operations inside the host service.
4. Validate all user input before invoking host commands.
5. Never add shell interpolation of user-controlled values.
6. Add tests for new validation and state transitions.
7. Update documentation and packaging when behavior changes.
8. Open a pull request with a clear description and test steps.

Security-sensitive networking changes should be discussed in an issue before implementation.
