# Linux Hotspot Manager 4.1.0 — GUI feature matrix

The GTK4/libadwaita GUI exposes the complete management surface of the current D-Bus service.

## GUI modules
- Dashboard: status, start/stop, diagnostics, refresh.
- Hotspot: SSID, WPA password, interface, band, channel, max clients, hidden SSID, gaming mode, LAN isolation, UPnP and profiles.
- Connected Devices: DHCP client list, block/unblock, MAC policy, per-client upload/download limits.
- Users: create, enable/disable and delete local accounts; time/data quota fields and session limits.
- Vouchers: batch prepaid-code generation, limits, redemption and listing.
- Captive Portal: title, message, redirect, terms, branding, logo/background, colors, TTL, account/voucher/terms/CAPTCHA options, free URLs and preview.
- Bandwidth: per-client limits, total capacity and dynamic rebalancing.
- Firewall: TCP/UDP allow/block rules, P2P/file-sharing control, LAN isolation and policy configuration.
- Web Filter: domain allow/block, category toggles, adblock, social/adult blocking and URL logging configuration.
- Network: router/ICS/bridge/repeater/no-sharing mode, gateway, DHCP, DNS and port forwarding.
- Statistics: interface traffic and JSON/CSV report export.
- Logs: event history and retention purge.
- Billing: pricing packages plus provider-neutral payment/SMS configuration.
- Security: staff accounts/roles, MAC policy and SSL portal configuration.
- Advanced: repeater, file sharing, QR join, multi-login, free-access and DHCP/priority settings.
- Settings: language, autostart, backup retention, diagnostics and database backup.

## Integration-dependent features
Payment gateways, SMS OTP, Wi-Fi repeater/bridge support, transparent captive-portal interception, full DNS URL logging and kernel-level quota enforcement depend on the host network stack, wireless driver and external provider. The GUI provides configuration controls rather than pretending these integrations are universally available.
