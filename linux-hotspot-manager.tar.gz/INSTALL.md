# Installation

## Debian/Ubuntu
Download the `.deb` from GitHub Releases:
`sudo apt install ./linux-hotspot-manager_3.2.0_all.deb`

## Arch Linux
Download the `.pkg.tar.*` asset:
`sudo pacman -U ./linux-hotspot-manager-3.2.0-1-any.pkg.tar.zst`

## Fedora
Download the `.rpm` asset:
`sudo dnf install ./linux-hotspot-manager-3.2.0-1.noarch.rpm`

## Flatpak
Download the `.flatpak` asset and install:
`flatpak install --user ./Linux-Hotspot-Manager-3.2.0.flatpak`
