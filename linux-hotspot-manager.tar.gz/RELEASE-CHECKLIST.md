# Release checklist

- [x] Python syntax validation
- [x] Polkit policy XML validation
- [x] D-Bus host-service architecture
- [x] NAT/forwarding
- [x] DNS filtering
- [x] Client accounting
- [x] Client quotas
- [x] Captive portal sessions
- [x] Hardware smoke-test script
- [x] Host install/uninstall scripts
- [ ] Real 2.4/5 GHz hardware matrix on target machines
- [ ] WPA3 validation on target adapters
- [ ] Clean Debian build
- [ ] Clean Arch build
- [ ] Clean Fedora/RPM build
- [ ] Verified Flatpak source checksums
