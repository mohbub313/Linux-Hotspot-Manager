# Linux Hotspot Manager

**v3.2.0-8 source snapshot** — a production-oriented, open-source Linux Wi-Fi hotspot manager with a GTK4/libadwaita GUI and a privileged D-Bus host service.

## Architecture

```text
GTK4/libadwaita GUI (unprivileged)
        |
        | system D-Bus
        v
Privileged host service (root)
   |       |       |       |
   v       v       v       v
NetworkManager nftables  tc    dnsmasq
        |
        v
   SQLite state
```

The GUI does not directly run privileged networking commands. The host service owns the privileged boundary.

## Main capabilities

- Hotspot lifecycle and WPA-PSK baseline
- NetworkManager D-Bus device/AP integration
- NAT/IPv4 forwarding foundation
- nftables firewall and per-client accounting foundation
- `tc` bandwidth-shaping foundation
- DNS/domain filtering with dnsmasq
- Guest users with salted scrypt password hashes
- Time/data quota state and enforcement foundation
- Captive-portal session state
- Polkit authorization foundation
- Live interface traffic statistics
- GTK4/libadwaita desktop UI
- systemd/D-Bus service activation
- Debian, Arch, RPM and Flatpak packaging infrastructure
- CI/release workflow and validation scripts

## v3.2.0-8 fixes

- GUI uses `dbus_next.glib.MessageBus`.
- D-Bus proxy methods are called using dbus-next's documented snake_case convention, e.g. `GetStatus` -> `call_get_status_sync`.
- Host service D-Bus method signatures include explicit type annotations.
- systemd tracks readiness with `Type=dbus` and `BusName=com.shazid.LinuxHotspotManager`.
- D-Bus system policy is included in the source tree.

## Build checks

```bash
python3 -m py_compile src/main.py host/linux-hotspot-manager-service.py portal/server.py
python3 -m unittest discover tests -v
```

Build a full Debian package on a Debian/Ubuntu/Parrot host:

```bash
./scripts/build-deb-full.sh
```

## Installation

For the provided Debian package:

```bash
sudo apt install ./linux-hotspot-manager_3.2.0-8_all.deb
linux-hotspot-manager
```

## Verification and limitations

This project is production-oriented but is **not a universal certification** for every Linux distribution, kernel, NetworkManager version, Wi-Fi chipset or driver. Real hardware testing is required, especially for AP mode, WPA3, channel/band selection, DHCP/DNS/NAT, quotas and captive-portal enforcement.

DNS-only domain filtering can be bypassed with encrypted DNS such as DoH/DoT. The project deliberately does not perform HTTPS interception.

Before a public stable release, maintainers should tighten the D-Bus policy, complete method-level polkit enforcement, run clean/chroot package builds, verify Flatpak source checksums, and sign reproducible release artifacts.

## Documentation

See `docs/` for architecture, installation, D-Bus API, NAT/forwarding, DNS filtering, traffic accounting, quota enforcement, captive portal, polkit, hardware testing, packaging and release guidance.

## License

See `LICENSE`.
